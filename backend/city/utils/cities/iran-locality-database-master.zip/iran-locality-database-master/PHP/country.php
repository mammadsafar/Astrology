<?php

$country = [
    [
        "id" => 1,
        "name" => "ایران",
        "latitude" => 32.56163037,
        "longitude" => 54.40429688
    ]
];

