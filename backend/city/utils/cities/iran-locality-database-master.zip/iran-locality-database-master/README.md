Locality of Iran
=============

Locality of Iran with Latitude and longitude

Province (State) and city with latitude and longitude available with:

-Access

-CSV

-Excel

-JSON

-PHP

-MySQL

-SQL

-XML

Country => Province => City
