iran-states-and-cities-json-and-sql-including-area-coordinations
================

iran states and cities in json and sql formats including area coordinations.



__By__: _[Farid Ahmadian]_

  [Farid Ahmadian]: http://pathseeker.ir
